# Generated script, do not edit
# Exports language-format specific env vars from startkde.
# This script has been generated from kcmshell5 formats.
# It will automatically be overwritten from there.
export LANG=fr_FR.UTF-8
